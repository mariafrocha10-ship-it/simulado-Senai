﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopeeMVC.Models;
using System.Text.Json;

namespace ShopeeMVC.Controllers
{
    public class CarrinhoController : Controller
    {
        private readonly DbShopeeContext _context;

        public CarrinhoController(DbShopeeContext context)
        {
            _context = context;
        }

        // OBTER O CARRINHO DA SESSION
        private List<CarrinhoItem> ObterCarrinho()
        {
            var carrinhoJson = HttpContext.Session.GetString("Carrinho");

            if (string.IsNullOrEmpty(carrinhoJson))
            {
                return new List<CarrinhoItem>();
            }

            return JsonSerializer.Deserialize<List<CarrinhoItem>>(carrinhoJson)
                   ?? new List<CarrinhoItem>();
        }

        // SALVAR O CARRINHO NA SESSION
        private void SalvarCarrinho(List<CarrinhoItem> carrinho)
        {
            var carrinhoJson = JsonSerializer.Serialize(carrinho);
            HttpContext.Session.SetString("Carrinho", carrinhoJson);
        }

        // EXIBIR O CARRINHO
        public IActionResult Index()
        {
            var carrinho = ObterCarrinho();
            return View(carrinho);
        }

        // ADICIONAR PRODUTO
        public async Task<IActionResult> Adicionar(int id)
        {
            var produto = await _context.Produtos
                .FirstOrDefaultAsync(p => p.Codigo == id);

            if (produto == null)
            {
                return NotFound();
            }

            var carrinho = ObterCarrinho();

            var item = carrinho.FirstOrDefault(x => x.ProdutoId == produto.Codigo);

            if (item == null)
            {
                carrinho.Add(new CarrinhoItem
                {
                    ProdutoId = produto.Codigo,
                    Nome = produto.Nome,
                    Preco = produto.Preco,
                    Quantidade = 1
                });
            }
            else
            {
                item.Quantidade++;
            }

            SalvarCarrinho(carrinho);

            return RedirectToAction(nameof(Index));
        }

        // REMOVER PRODUTO
        public IActionResult Remover(int id)
        {
            var carrinho = ObterCarrinho();

            var item = carrinho.FirstOrDefault(x => x.ProdutoId == id);

            if (item != null)
            {
                carrinho.Remove(item);
            }

            SalvarCarrinho(carrinho);

            return RedirectToAction(nameof(Index));
        }
    }
}