﻿using System.ComponentModel.DataAnnotations;

namespace ShopeeMVC.Models
{
    public class CarrinhoItem
    {
        [Key]
        public int ProdutoId { get; set; }
        public string Nome { get; set; } = string.Empty;
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }

        public decimal Subtotal
        {
            get
            {
                return Preco * Quantidade;
            }
        }
    }
}