using Microsoft.EntityFrameworkCore;
using ShopeeMVC.Models;

var builder = WebApplication.CreateBuilder(args);
    builder.Services.AddControllersWithViews();
    
    builder.Services.AddDbContext<DbShopeeContext>(options => options.UseSqlServer(
    
        builder.Configuration.GetConnectionString("ConexaoBanco")));

    builder.Services.AddDistributedMemoryCache();

    builder.Services.AddSession();
        var app = builder.Build();
    if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
    app.UseHttpsRedirection();
   
    app.UseStaticFiles();
    
    app.UseRouting();
    
    app.UseSession();

    app.UseAuthorization();

    app.MapControllerRoute(
       

name: "default",
pattern: "{controller=Produto}/{action=Index}/{id?}");

app.Run();